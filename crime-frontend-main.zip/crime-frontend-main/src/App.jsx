import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Flex } from '@chakra-ui/react';
import NavBar from './components/NavBar';
import HomePage from './pages/HomePage';
import Query1Page from './pages/Query1Page';
import Query2Page from './pages/Query2Page';
import Query3Page from './pages/Query3Page';
import Query4Page from './pages/Query4Page';
import Query5Page from './pages/Query5Page';

function App() {
  return (
    <Router>
      <Flex>
        <NavBar />
        <Flex flex="1" ml="15%"> {/* Responsive margin-left */}
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/query1" element={<Query1Page />} />
            <Route path="/query2" element={<Query2Page />} />
            <Route path="/query3" element={<Query3Page />} />
            <Route path="/query4" element={<Query4Page />} />
            <Route path="/query5" element={<Query5Page />} />
          </Routes>
        </Flex>
      </Flex>
    </Router>
  );
}

export default App;
