import React from 'react';
import {
    BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer
} from 'recharts';

const ClusteredBarChart = ({ data }) => {
    const barColors = [
        '#8884d8', '#82ca9d', '#ffc658', '#ff7300', '#413ea0',
        '#e6194B', '#f58231', '#ffe119', '#bfef45', '#3cb44b',
        '#42d4f4', '#4363d8', '#911eb4', '#f032e6', '#fabed4',
        '#469990', '#dcbeff', '#9A6324', '#fffac8', '#800000',
        '#aaffc3', '#000075'
    ]; // Colors for the bars

    // Determine the keys dynamically excluding 'crimeDescription'
    const keys = data.length > 0 ? Object.keys(data[0]).filter(k => k !== 'crimeDescription') : [];

    return (
        <ResponsiveContainer width="100%" height={400}>
            <BarChart
                data={data}
                margin={{
                    top: 20, right: 30, left: 20, bottom: 5,
                }}
                barGap={3}  // Adjusts the gap between bars within clusters
                barCategoryGap={20}  // Adjusts the gap between clusters
            >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="crimeDescription" />
                <YAxis />
                <Tooltip />
                <Legend />
                {keys.map((key, index) => (
                    <Bar key={key} dataKey={key} fill={barColors[index % barColors.length]} />
                ))}
            </BarChart>
        </ResponsiveContainer>
    );
};

export default ClusteredBarChart;
