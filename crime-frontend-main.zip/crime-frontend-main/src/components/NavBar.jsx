import React from 'react';
import { Box, VStack, Link, Text } from '@chakra-ui/react';
import { Link as RouterLink } from 'react-router-dom';

const NavBar = () => {
    return (
        <Box width="15%" position="fixed" height="100vh" bg="#2A4365" zIndex="2" fontFamily="Montserrat, sans-serif">
            <RouterLink to="/" style={{ textDecoration: 'none' }}>
                <Text fontSize="xl" fontWeight="bold" color="white" textAlign="center" marginBottom="20px" marginTop="20px">LA Crime InvestiGator</Text>
            </RouterLink>
            <VStack as="nav" spacing={0.5} align="center">
                <Link as={RouterLink} to="/query1" sx={{
                    textDecoration: 'none',
                    backgroundColor: '#2C5282',
                    color: 'white',
                    padding: '8px',
                    fontWeight: 'bold',
                    width: '100%',
                    textAlign: 'center',
                    paddingY:5,
                    '&:hover': {
                        backgroundColor: 'white',
                        color: '#2C5282',
                    }
                }}>Crime Category</Link>
                {/* Repeat for other links with appropriate `to` attributes */}
                <Link as={RouterLink} to="/query2" sx={{
                    textDecoration: 'none',
                    backgroundColor: '#2C5282',
                    color: 'white',
                    padding: '8px',
                    fontWeight: 'bold',
                    width: '100%',
                    textAlign: 'center',
                    paddingY:5,
                    '&:hover': {
                        backgroundColor: 'white',
                        color: '#2C5282',
                    }
                }}>Weapon Type</Link>
                <Link as={RouterLink} to="/query3" sx={{
                    textDecoration: 'none',
                    backgroundColor: '#2C5282',
                    color: 'white',
                    padding: '8px',
                    fontWeight: 'bold',
                    width: '100%',
                    textAlign: 'center',
                    paddingY:5,
                    '&:hover': {
                        backgroundColor: 'white',
                        color: '#2C5282',
                    }
                }}>Victim Demographics</Link>
                <Link as={RouterLink} to="/query4" sx={{
                    textDecoration: 'none',
                    backgroundColor: '#2C5282',
                    color: 'white',
                    padding: '8px',
                    fontWeight: 'bold',
                    width: '100%',
                    textAlign: 'center',
                    paddingY:5,
                    '&:hover': {
                        backgroundColor: 'white',
                        color: '#2C5282',
                    }
                }}>Report Time Discrepancy</Link>
                <Link as={RouterLink} to="/query5" sx={{
                    textDecoration: 'none',
                    backgroundColor: '#2C5282',
                    color: 'white',
                    padding: '8px',
                    fontWeight: 'bold',
                    width: '100%',
                    textAlign: 'center',
                    paddingY:5,
                    '&:hover': {
                        backgroundColor: 'white',
                        color: '#2C5282',
                    }
                }}>Crime Premises</Link>
            </VStack>
        </Box>
    );
};

export default NavBar;
