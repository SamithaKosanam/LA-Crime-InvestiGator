export default async function customFetch(url, method, body) {
  try {
    // Perform the fetch operation
    const BASE_URL = "http://localhost:4000";
    url = BASE_URL + url;
    const fetchResponse = await fetch(url, {
      method: method,
      body: body, // Use adjustedBody which may be either FormData or a JSON string
    });

    return fetchResponse;
  } catch (error) {
    console.error("Error in customFetch:", error);
    return {
      ok: false,
      status: 400,
      json: async () => ({ error: error.toString() }),
    };
  }
}