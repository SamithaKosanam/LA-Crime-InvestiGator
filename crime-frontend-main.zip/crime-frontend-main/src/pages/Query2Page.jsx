import React, { useState, useEffect } from 'react';
import { Stack, Radio, RadioGroup, Text, Flex, Button, Box, VStack, FormControl, FormLabel } from '@chakra-ui/react';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import Select from 'react-select';
import customFetch from '../customFetch';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, Brush } from 'recharts';
import moment from 'moment';
import CustomPieChart from '../components/CustomPieChart';

export default function Query2Page() {
    const [startDate, setStartDate] = useState(new Date(2021, 0, 1));
    const [endDate, setEndDate] = useState(new Date(2021, 11, 31));
    const [selectedAreas, setSelectedAreas] = useState([]);
    const [areaOptions, setAreaOptions] = useState([
        { value: 'option1', label: 'Option 1' },
        { value: 'option2', label: 'Option 2' },
        { value: 'option3', label: 'Option 3' },
    ]);
    const [selectedWeapons, setSelectedWeapons] = useState([]);
    const [weaponOptions, setWeaponOptions] = useState([
        { value: 'option1', label: 'Option 1' },
        { value: 'option2', label: 'Option 2' },
        { value: 'option3', label: 'Option 3' },
    ]);
    const [interval, setInterval] = useState("daily");
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(false);
    const [graphArea, setGraphArea] = useState("");
    const [graphWeapons, setGraphWeapons] = useState([]);
    const [graphPieData, setGraphPieData] = useState([]);
    const [graphInterval, setGraphInterval] = useState("daily");

    useEffect(() => {
        async function fetchAreas() {
            const response = await customFetch('/api/areas', 'GET');
            if (response.ok) {
                const data = await response.json();
                const newOptions = data.map(area => ({ value: area[1], label: area[1] }));
                setAreaOptions(newOptions);
            } else {
                // If the fetch fails, we stick with the default options set in the useState hook
                console.error('Error fetching areas. Using default options.');
            }
        }
        async function fetchWeaponTypes() {
            const response = await customFetch('/api/weaponTypes', 'GET');
            if (response.ok) {
                const data = await response.json();
                const newOptions = data.map(weaponType => ({ value: weaponType[0], label: weaponType[0] }));
                setWeaponOptions(newOptions);
            } else {
                // If the fetch fails, we stick with the default options set in the useState hook
                console.error('Error fetching crimes. Using default options.');
            }
        }
        fetchAreas();
        fetchWeaponTypes();
    }, []);


    // Define custom styles for react-select based on Chakra UI's design system
    const customStyles = {
        control: (provided) => ({
            ...provided,
            borderRadius: '0.375rem', // 6px
            borderColor: '#E2E8F0',
            boxShadow: 'sm',
            minHeight: '32px',
            '&:hover': {
                borderColor: '#CBD5E0',
            },
        }),
        multiValue: (provided) => ({
            ...provided,
            backgroundColor: '#EBF8FF',
        }),
        multiValueLabel: (provided) => ({
            ...provided,
            color: '#1A202C',
        }),
        multiValueRemove: (provided) => ({
            ...provided,
            color: '#718096',
            '&:hover': {
                backgroundColor: '#E53E3E',
                color: 'white',
            },
        }),
    };

    const handleSubmit = async () => {
        setLoading(true);
        const formatDateString = (date) => {
            const year = date.getFullYear();
            const month = (`0${date.getMonth() + 1}`).slice(-2); // Months are 0-indexed, add 1 to get the correct month
            const day = (`0${date.getDate()}`).slice(-2);
            return `${year}-${month}-${day}`;
        };
    
        const formattedStartDate = formatDateString(startDate);
        const formattedEndDate = formatDateString(endDate);

        const queryParams = new URLSearchParams({
            startDate: formattedStartDate,
            endDate: formattedEndDate,
            areas: selectedAreas.value,
            interval: interval
        });
        
        // Append 'weaponDescription' parameter for each selected weapon description
        selectedWeapons.forEach(weapon => queryParams.append('weaponDescriptions', weapon.value));
        setGraphArea(selectedAreas.value);
        setGraphWeapons(selectedWeapons.map(weapon => weapon.value));
        setGraphInterval(interval);
        try {
            const response = await customFetch(`/api/query2?${queryParams}`, 'GET');
            if (response.ok) {
                const jsonData = await response.json();
                const processedData = processDataForGraph(jsonData, interval);
                setData(processedData); // This should now correctly update the graph
                let percentageData = processDataForPieChart(jsonData, graphWeapons);
                //console.log("percentageData: ", JSON.stringify(jsonData, null, 2));
                setGraphPieData(percentageData);
            } else {
                console.error('Failed to fetch data');
                setData([]); // Ensure to clear data or set to a default state indicating no results
            }            
        } catch (error) {
            console.error('Fetch error:', error);
        } finally {
            setLoading(false);
        }
    };
    
    const processDataForGraph = (jsonData, interval) => {
        let graphData = [];
        let weaponTypesSet = new Set();
    
        // Identify all unique weapon types
        Object.values(jsonData).forEach(areaData => {
            Object.values(areaData).forEach(weapons => {
                weapons.forEach(weapon => weaponTypesSet.add(weapon.weaponDescription));
            });
        });
    
        // Prepare date range for iteration
        const allPeriods = Object.keys(jsonData).sort();
        const format = interval === 'daily' ? 'YYYY-MM-DD' : 'YYYY-MM';
        const addUnit = interval === 'daily' ? 'days' : 'months';
        let currentDate = allPeriods[0];
        const endDate = allPeriods[allPeriods.length - 1];
    
        while (currentDate <= endDate) {
            const periodData = jsonData[currentDate] || {};
            weaponTypesSet.forEach(weaponType => {
                const weaponData = periodData[graphArea]?.find(cd => cd.weaponDescription === weaponType);
                const dataKey = `weaponType_${weaponType.replace(/[^a-zA-Z0-9]/g, "_")}`;
    
                if (!graphData[currentDate]) graphData[currentDate] = { date: currentDate };
    
                graphData[currentDate][dataKey] = weaponData ? weaponData.count : 0;
            });
    
            // Move to the next day or month
            currentDate = moment(currentDate, format).add(1, addUnit).format(format);
        }
    
        // Convert object back to array for charting
        return Object.values(graphData);
    };
    
    function processDataForPieChart(jsonData, allWeaponTypes) {
        const weaponTypeSums = {};
        const weaponTypeCounts = {};
        const weaponTypeAverages = [];
    
        // Initialize sums and counts for each weapon type
        allWeaponTypes.forEach(weaponType => {
            weaponTypeSums[weaponType] = 0;
            weaponTypeCounts[weaponType] = 0;
        });
    
        // Iterate through each period (e.g., month or day)
        Object.entries(jsonData).forEach(([period, dataByArea]) => {
            // Assuming data is aggregated by area; focusing on a specific area or adjusting as needed
            const crimesInPeriod = dataByArea[graphArea] || [];
    
            allWeaponTypes.forEach(weaponType => {
                
                const weaponData = crimesInPeriod.find(c => c.weaponDescription === weaponType);
                
                if (weaponData) {
                    // Sum percentages for averaging later
                    weaponTypeSums[weaponType] += weaponData.percentage;
                    weaponTypeCounts[weaponType] += 1;
                }
            });
        });
    
        // Calculate averages
        allWeaponTypes.forEach(weaponType => {
            // Ensure division by zero is handled
            if (weaponTypeCounts[weaponType] > 0) {
                weaponTypeAverages.push({
                    name: weaponType,
                    value: weaponTypeSums[weaponType] / weaponTypeCounts[weaponType]
                });
            } else {
                // If a weapon is never used, assign it a 0% average
                weaponTypeAverages.push({
                    name: weaponType,
                    value: 0
                });
            }
        });
    
        return weaponTypeAverages;
    }
    
    
    const title = data && data.length > 0 ? 
    `Distribution of selected weapon types in ${graphArea} from ${startDate.toDateString()} to ${endDate.toDateString()}` : 
    "Loading graph...";
    const pieTitle = graphInterval === 'daily' ? 'Average Percentage Per Crime Per Day' : 'Average Percentage Per Crime Per Month';
    const weaponTypeKeys = data.length > 0 ? Object.keys(data[0]).filter(key => key !== 'date') : [];

    const colors = [
        '#8884d8', '#82ca9d', '#ffc658', '#ff7300', '#413ea0',
        '#e6194B', '#f58231', '#ffe119', '#bfef45', '#3cb44b',
        '#42d4f4', '#4363d8', '#911eb4', '#f032e6', '#fabed4',
        '#469990', '#dcbeff', '#9A6324', '#fffac8', '#800000',
        '#aaffc3', '#000075'
    ];
    

    const getRandomColor = (index) => colors[index % colors.length];    

    return (
       <Flex direction="row" align="center" justify="center" minHeight="100vh" bg="gray.100" w="100vw">
            <Box display="flex" justifyContent="center" alignItems="center" minHeight="100vh" width="30%">
                <VStack align="start" spacing={4} border="1px solid" borderColor="gray.200" p={5} borderRadius="md" bg="white">
                    <FormControl>
                        <FormLabel>Start Date</FormLabel>
                        <DatePicker
                            selected={startDate}
                            onChange={(date) => setStartDate(date)}
                            selectsStart
                            startDate={startDate}
                            endDate={endDate}
                            maxDate={new Date('2023-12-31')}
                            minDate={new Date('2020-01-01')}
                            dateFormat="MMMM d, yyyy"
                            className="chakra-input css-0"
                            style={{border: '1px solid #E2E8F0', borderRadius: '0.375rem', padding: '0.5rem'}}
                        />
                    </FormControl>
                    <FormControl>
                        <FormLabel>End Date</FormLabel>
                        <DatePicker
                            selected={endDate}
                            onChange={(date) => setEndDate(date)}
                            selectsEnd
                            startDate={startDate}
                            endDate={endDate}
                            minDate={startDate}
                            maxDate={new Date('2023-12-31')}
                            dateFormat="MMMM d, yyyy"
                            className="chakra-input css-0"
                            style={{border: '1px solid #E2E8F0', borderRadius: '0.375rem', padding: '0.5rem'}}
                        />
                    </FormControl>
                    <FormControl>
                        <FormLabel>Area Select</FormLabel>
                        <Select
                            options={areaOptions}
                            classNamePrefix="select"
                            value={selectedAreas}
                            onChange={setSelectedAreas}
                            styles={customStyles}
                        />
                    </FormControl>
                    <FormControl>
                        <FormLabel>Weapon Type Select</FormLabel>
                        <Select
                            isMulti
                            options={weaponOptions}
                            classNamePrefix="select"
                            value={selectedWeapons}
                            onChange={setSelectedWeapons}
                            styles={customStyles}
                        />
                    </FormControl>
                    <FormControl as="fieldset">
                        <FormLabel as="legend">Interval</FormLabel>
                        <RadioGroup onChange={setInterval} value={interval}>
                            <Stack direction="row">
                                <Radio value="daily">Daily</Radio>
                                <Radio value="monthly">Monthly</Radio>
                            </Stack>
                        </RadioGroup>
                    </FormControl>
                    <Button colorScheme="blue" onClick={handleSubmit}>Submit</Button> {/* Add this Button */}
                </VStack>
            </Box>
            <Box width="60%" marginLeft="5%">
                {data.length === 0 ? (
                     <Text color="red">No weapons in this area with this type in this time frame</Text>
                ) : (
                    <Flex direction="column" align="center" justify="center">
                        <Text fontSize="xl" fontWeight="bold" mb={4}>{title}</Text>
                        <LineChart
                            width={1000}
                            height={600}
                            data={data}
                            margin={{
                                top: 5, right: 30, left: 20, bottom: 5,
                            }}
                        >
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="date" />
                            <YAxis />
                            <Tooltip />
                            <Legend />
                            {
                                // Dynamically create a Line component for each crime type
                                weaponTypeKeys.map((key, index) => (
                                    <Line 
                                        key={index} 
                                        type="monotone" 
                                        dataKey={key} 
                                        stroke={getRandomColor(index)} // Assign a color function based on index or key
                                        activeDot={{ r: 8 }}
                                    />
                                ))
                            }
                            <Brush dataKey="date" height={30} stroke="#8884d8" />
                        </LineChart>
                        <Text fontSize="xl" fontWeight="bold" mb={4}>{pieTitle}</Text>
                        <CustomPieChart data={graphPieData} />
                    </Flex>
                )}
            </Box>
        </Flex>
    );
}
