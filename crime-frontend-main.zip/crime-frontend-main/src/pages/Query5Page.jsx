import React, { useState, useEffect } from 'react';
import { Stack, Radio, RadioGroup, Text, Flex, Button, Box, VStack, FormControl, FormLabel } from '@chakra-ui/react';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import Select from 'react-select';
import customFetch from '../customFetch';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, Brush } from 'recharts';
import moment from 'moment';
import CustomPieChart from '../components/CustomPieChart';

export default function Query5() {
    const [startDate, setStartDate] = useState(new Date(2021, 0, 1));
    const [endDate, setEndDate] = useState(new Date(2021, 11, 31));
    const [selectedPremise, setSelectedPremise] = useState([]);
    const [premiseOptions, setPremiseOptions] = useState([
        { value: 'option1', label: 'Option 1' },
        { value: 'option2', label: 'Option 2' },
        { value: 'option3', label: 'Option 3' },
    ]);
    const [selectedCrimes, setSelectedCrimes] = useState([]);
    const [crimeOptions, setCrimeOptions] = useState([
        { value: 'option1', label: 'Option 1' },
        { value: 'option2', label: 'Option 2' },
        { value: 'option3', label: 'Option 3' },
    ]);
    const [interval, setInterval] = useState("daily");
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(false);
    const [graphArea, setGraphArea] = useState("");
    const [crimeLocation, setCrimeLocation] = useState("");

    const [graphCrimes, setGraphCrimes] = useState([]);
    const [graphPieData, setGraphPieData] = useState([]);
    const [graphInterval, setGraphInterval] = useState("daily");

    useEffect(() => {
        async function fetchAreas() {
            const response = await customFetch('/api/premises', 'GET');
            if (response.ok) {
                const data = await response.json();
                const newOptions = data.map(area => ({ value: area[1], label: area[1] }));
                setPremiseOptions(newOptions);
            } else {
                // If the fetch fails, we stick with the default options set in the useState hook
                console.error('Error fetching areas. Using default options.');
            }
        }
        async function fetchCrimetypes() {
            const response = await customFetch('/api/crimeTypes', 'GET');
            if (response.ok) {
                const data = await response.json();
                const newOptions = data.map(crimeType => ({ value: crimeType[1], label: crimeType[1] }));
                setCrimeOptions(newOptions);
            } else {
                // If the fetch fails, we stick with the default options set in the useState hook
                console.error('Error fetching crimes. Using default options.');
            }
        }
        fetchAreas();
        fetchCrimetypes();
    }, []);


    // Define custom styles for react-select based on Chakra UI's design system
    const customStyles = {
        control: (provided) => ({
            ...provided,
            borderRadius: '0.375rem', // 6px
            borderColor: '#E2E8F0',
            boxShadow: 'sm',
            minHeight: '32px',
            '&:hover': {
                borderColor: '#CBD5E0',
            },
        }),
        multiValue: (provided) => ({
            ...provided,
            backgroundColor: '#EBF8FF',
        }),
        multiValueLabel: (provided) => ({
            ...provided,
            color: '#1A202C',
        }),
        multiValueRemove: (provided) => ({
            ...provided,
            color: '#718096',
            '&:hover': {
                backgroundColor: '#E53E3E',
                color: 'white',
            },
        }),
    };

    const handleSubmit = async () => {
        setLoading(true);
        setCrimeLocation(selectedPremise.value)
        const formatDateString = (date) => {
            const year = date.getFullYear();
            const month = (`0${date.getMonth() + 1}`).slice(-2); // Months are 0-indexed, add 1 to get the correct month
            const day = (`0${date.getDate()}`).slice(-2);
            return `${year}-${month}-${day}`;
        };    

        const formattedStartDate = formatDateString(startDate);
        const formattedEndDate = formatDateString(endDate);

        const queryParams = new URLSearchParams({
            startDate: formattedStartDate,
            endDate: formattedEndDate,
            premise: selectedPremise.value,
            interval: interval
        });
        selectedCrimes.forEach(crime => queryParams.append('crimeDescriptions', crime.value));

        setGraphArea(selectedCrimes.value);
        setGraphCrimes(selectedCrimes.map(crime => crime.value));

        console.log("setGraphArea", graphArea);
        setGraphInterval(interval);

        try {
            const response = await customFetch(`/api/query5?${queryParams}`, 'GET');
            if (response.ok) {
                const jsonData = await response.json();
                const processedData = processDataForGraph(jsonData, interval);
                console.log("processedData", processedData);
                setData(processedData); // This should now correctly update the graph
                let totalNum = calculateTotals(processedData);
                console.log(totalNum)
                let percentageData = processDataForPieChart(totalNum);
                console.log(percentageData);
                setGraphPieData(percentageData);
            } else {
                console.error('Failed to fetch data');
                setData([]); // Ensure to clear data or set to a default state indicating no results
            }            
        } catch (error) {
            console.error('Fetch error:', error);
        } finally {
            setLoading(false);
        }
    };

    const processDataForGraph = (dataSet, interval) => {
        const transformedData = [];
        const allCrimeTypes = graphCrimes;
        console.log(allCrimeTypes)

        for (const date in dataSet) {
            const crimeTypes = dataSet[date];
            const entry = { date: date };
    
            // Initialize all crime types to 0
            allCrimeTypes.forEach(crimeType => {
                entry[crimeType] = 0;
            });
    
            // Update counts for existing crime types
            for (const crimeType in crimeTypes) {
                const count = crimeTypes[crimeType][0].crimeDescription;
                entry[crimeType] = count;
            }
    
            transformedData.push(entry);
        }
    
        return transformedData;
    };
    
    const processDataForPieChart = (totalCounts) => {
        const total = Object.values(totalCounts).reduce((acc, count) => acc + count, 0);
        const percentages = Object.entries(totalCounts).map(([crimeType, count]) => ({
            name: crimeType,
            value: (count / total) * 100
        }));
        return percentages;
    };
    
    function calculateTotals(processedData) {

        const total = processedData.reduce((acc, entry) => {
            for (const crimeType in entry) {
                if (crimeType !== 'date') {
                    acc[crimeType] = (acc[crimeType] || 0) + entry[crimeType];
                }
            }
            return acc;
        }, {});

        return total
    }
    
    const title = data && data.length > 0 ? 
    `Crime in ${crimeLocation} from ${startDate.toDateString()} to ${endDate.toDateString()}` : 
    "Loading graph...";
    const pieTitle = graphInterval === 'daily' ? 'Average Percentage Per Crime Per Day ' : 'Average Percentage Per Crime Per Month';
    const crimeTypeKeys = data.length > 0 ? Object.keys(data[0]).filter(key => key !== 'date') : [];

    const colors = [
        '#8884d8', '#82ca9d', '#ffc658', '#ff7300', '#413ea0',
        '#e6194B', '#f58231', '#ffe119', '#bfef45', '#3cb44b',
        '#42d4f4', '#4363d8', '#911eb4', '#f032e6', '#fabed4',
        '#469990', '#dcbeff', '#9A6324', '#fffac8', '#800000',
        '#aaffc3', '#000075'
    ];
    

    const getRandomColor = (index) => colors[index % colors.length];    

    return (
       <Flex direction="row" align="center" justify="center" minHeight="100vh" bg="gray.100" w="100vw">
            <Box display="flex" justifyContent="center" alignItems="center" minHeight="100vh" width="30%">
                <VStack align="start" spacing={4} border="1px solid" borderColor="gray.200" p={5} borderRadius="md" bg="white">
                    <FormControl>
                        <FormLabel>Start Date</FormLabel>
                        <DatePicker
                            selected={startDate}
                            onChange={(date) => setStartDate(date)}
                            selectsStart
                            startDate={startDate}
                            endDate={endDate}
                            maxDate={new Date('2023-12-31')}
                            minDate={new Date('2020-01-01')}
                            dateFormat="MMMM d, yyyy"
                            className="chakra-input css-0"
                            style={{border: '1px solid #E2E8F0', borderRadius: '0.375rem', padding: '0.5rem'}}
                        />
                    </FormControl>
                    <FormControl>
                        <FormLabel>End Date</FormLabel>
                        <DatePicker
                            selected={endDate}
                            onChange={(date) => setEndDate(date)}
                            selectsEnd
                            startDate={startDate}
                            endDate={endDate}
                            minDate={startDate}
                            maxDate={new Date('2023-12-31')}
                            dateFormat="MMMM d, yyyy"
                            className="chakra-input css-0"
                            style={{border: '1px solid #E2E8F0', borderRadius: '0.375rem', padding: '0.5rem'}}
                        />
                    </FormControl>
                    <FormControl>
                        <FormLabel>Premise Select</FormLabel>
                        <Select
                            options={premiseOptions}
                            classNamePrefix="select"
                            value={selectedPremise}
                            onChange={setSelectedPremise}
                            styles={customStyles}
                        />
                    </FormControl>
                    <FormControl>
                        <FormLabel>Crime Type Select</FormLabel>
                        <Select
                            isMulti
                            options={crimeOptions}
                            classNamePrefix="select"
                            value={selectedCrimes}
                            onChange={setSelectedCrimes}
                            styles={customStyles}
                        />
                    </FormControl>
                    <FormControl as="fieldset">
                        <FormLabel as="legend">Interval</FormLabel>
                        <RadioGroup onChange={setInterval} value={interval}>
                            <Stack direction="row">
                                <Radio value="daily">Daily</Radio>
                                <Radio value="monthly">Monthly</Radio>
                            </Stack>
                        </RadioGroup>
                    </FormControl>
                    <Button colorScheme="blue" onClick={handleSubmit}>Submit</Button> {/* Add this Button */}
                </VStack>
            </Box>
            <Box width="60%" marginLeft="5%">
                {data.length === 0 ? (
                     <Text color="red">No crimes in this area with this type in this time frame</Text>
                ) : (
                    <Flex direction="column" align="center" justify="center">
                        <Text fontSize="xl" fontWeight="bold" mb={4}>{title}</Text>
                        <LineChart
                            width={1000}
                            height={600}
                            data={data}
                            margin={{
                                top: 5, right: 30, left: 20, bottom: 5,
                            }}
                        >
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="date" />
                            <YAxis />
                            <Tooltip />
                            <Legend />
                            {
                                // Dynamically create a Line component for each crime type
                                crimeTypeKeys.map((key, index) => (
                                    <Line 
                                        key={index} 
                                        type="monotone" 
                                        dataKey={key} 
                                        stroke={getRandomColor(index)} // Assign a color function based on index or key
                                        activeDot={{ r: 8 }}
                                    />
                                ))
                            }
                            <Brush dataKey="date" height={30} stroke="#8884d8" />
                        </LineChart>
                        <Text fontSize="xl" fontWeight="bold" mb={4}>{pieTitle}</Text>
                        <CustomPieChart data={graphPieData} />
                    </Flex>
                )}
            </Box>
        </Flex>
    );
}
