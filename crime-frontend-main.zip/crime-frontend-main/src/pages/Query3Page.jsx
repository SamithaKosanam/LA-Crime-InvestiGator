import React, { useState, useEffect } from 'react';
import { Stack, Radio, RadioGroup, Text, Flex, Button, Box, VStack, FormControl, FormLabel } from '@chakra-ui/react';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import Select from 'react-select';
import customFetch from '../customFetch';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, Brush } from 'recharts';
import moment from 'moment';
import ClusteredBarChart from '../components/ClusteredBarChart';

export default function Query3Page() {
    const [startDate, setStartDate] = useState(new Date(2021, 0, 1));
    const [endDate, setEndDate] = useState(new Date(2021, 11, 31));
    const [selectedDemographic, setSelectedDemographic] = useState("");
    const [demographicOptions, setDemographicOptions] = useState([
        { value: 'age', label: 'Age' },
        { value: 'sex', label: 'Sex' },
        { value: 'descent', label: 'Descent' },
    ]);
    const [selectedCrimes, setSelectedCrimes] = useState([]);
    const [crimeOptions, setCrimeOptions] = useState([
        { value: 'option1', label: 'Option 1' },
        { value: 'option2', label: 'Option 2' },
        { value: 'option3', label: 'Option 3' },
    ]);
    const [interval, setInterval] = useState("daily");
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(false);
    const [graphDemographic, setGraphDemographic] = useState("");
    const [graphCrimes, setGraphCrimes] = useState([]);
    const [barGraphData, setBarGraphData] = useState([]);
    const [graphInterval, setGraphInterval] = useState("daily");

    useEffect(() => {
        async function fetchCrimetypes() {
            const response = await customFetch('/api/crimeTypes', 'GET');
            if (response.ok) {
                const data = await response.json();
                const newOptions = data.map(crimeType => ({ value: crimeType[1], label: crimeType[1] }));
                setCrimeOptions(newOptions);
            } else {
                // If the fetch fails, we stick with the default options set in the useState hook
                console.error('Error fetching crimes. Using default options.');
            }
        }
        fetchCrimetypes();
    }, []);

    // Define custom styles for react-select based on Chakra UI's design system
    const customStyles = {
        control: (provided) => ({
            ...provided,
            borderRadius: '0.375rem', // 6px
            borderColor: '#E2E8F0',
            boxShadow: 'sm',
            minHeight: '32px',
            '&:hover': {
                borderColor: '#CBD5E0',
            },
        }),
        multiValue: (provided) => ({
            ...provided,
            backgroundColor: '#EBF8FF',
        }),
        multiValueLabel: (provided) => ({
            ...provided,
            color: '#1A202C',
        }),
        multiValueRemove: (provided) => ({
            ...provided,
            color: '#718096',
            '&:hover': {
                backgroundColor: '#E53E3E',
                color: 'white',
            },
        }),
    };

    const descentCodes = {
        A: "Other Asian",
        B: "Black",
        C: "Chinese",
        D: "Cambodian",
        F: "Filipino",
        G: "Guamanian",
        H: "Hispanic/Latin/Mexican",
        I: "American Indian/Alaskan Native",
        J: "Japanese",
        K: "Korean",
        L: "Laotian",
        O: "Other",
        P: "Pacific Islander",
        S: "Samoan",
        U: "Hawaiian",
        V: "Vietnamese",
        W: "White",
        X: "Unknown",
        Z: "Asian Indian",
        '-': "Unknown"
    };
    
    const sexCodes = {
        M: "Male",
        F: "Female",
        X: "Other",  
        H: "Transgender"
    };
    
    const handleSubmit = async () => {
        setLoading(true);
        const formatDateString = (date) => {
            const year = date.getFullYear();
            const month = (`0${date.getMonth() + 1}`).slice(-2); // Months are 0-indexed, add 1 to get the correct month
            const day = (`0${date.getDate()}`).slice(-2);
            return `${year}-${month}-${day}`;
        };
    
        const formattedStartDate = formatDateString(startDate);
        const formattedEndDate = formatDateString(endDate);

        const queryParams = new URLSearchParams({
            startDate: formattedStartDate,
            endDate: formattedEndDate,
            type: selectedDemographic.value,
            interval: interval
        });
        console.log("params baby", queryParams)
        // Append 'crimeDescription' parameter for each selected crime description
        selectedCrimes.forEach(crime => queryParams.append('crimeDescriptions', crime.value));
        
        setGraphDemographic(selectedDemographic.value);
        setGraphCrimes(selectedCrimes.map(crime => crime.value));
        setGraphInterval(interval);
        try {
            const response = await customFetch(`/api/query3?${queryParams}`, 'GET');
            if (response.ok) {
                const jsonData = await response.json();
                console.log("JSONDATA", jsonData)
                const processedData = processDataForGraph(jsonData, graphDemographic);
                console.log("Processed data", processedData)
                setData(processedData); // This should now correctly update the graph
                const barChartData = createBarChart(jsonData, graphDemographic)
                setBarGraphData(barChartData)
                console.log("Barchart data", barChartData)
            } else {
                console.error('Failed to fetch data');
                setData([]); // Ensure to clear data or set to a default state indicating no results
            }            
        } catch (error) {
            console.error('Fetch error:', error);
        } finally {
            setLoading(false);
        }
    };

    function processDataForGraph(data, type) {
        const formattedData = [];
        const allDates = new Set();
        const typeCodes = {
            'sex': sexCodes,
            'descent': descentCodes
        };
        const allCategories = new Set();
        const allCrimes = new Set();
    
        // Extract all dates, categories, and crime descriptions
        for (const date in data) {
            allDates.add(date);
            for (const categoryCode in data[date]) {
                allCategories.add(categoryCode);
                data[date][categoryCode].forEach(crime => {
                    allCrimes.add(crime.crimeDescription);
                });
            }
        }
    
        // Convert dates to array and sort (to ensure correct order in graph)
        const sortedDates = Array.from(allDates).sort();
    
        // Initialize data structure for each date
        sortedDates.forEach(date => {
            const dateEntry = { date };
            allCategories.forEach(categoryCode => {
                allCrimes.forEach(crime => {
                    let key = `${categoryCode}-${crime.replace(/\s+/g, '')}`; // Default format
                    if (type !== 'age') {
                        const readableCategory = typeCodes[type][categoryCode] || "Unknown";
                        key = `${readableCategory}-${crime.replace(/\s+/g, '')}`; // Use translated category
                    }
                    dateEntry[key] = 0; // Initialize all crime counts to zero
                });
            });
    
            if (data[date]) {
                Object.keys(data[date]).forEach(categoryCode => {
                    data[date][categoryCode].forEach(crimeEntry => {
                        let key = `${categoryCode}-${crimeEntry.crimeDescription.replace(/\s+/g, '')}`;
                        if (type !== 'age') {
                            const readableCategory = typeCodes[type][categoryCode] || "Unknown";
                            key = `${readableCategory}-${crimeEntry.crimeDescription.replace(/\s+/g, '')}`;
                        }
                        dateEntry[key] = crimeEntry.count;
                    });
                });
            }
    
            formattedData.push(dateEntry);
        });
    
        return formattedData;
    }

    function createBarChart(data, type) {
        const typeCodes = {
            'sex': sexCodes,
            'descent': descentCodes
        };
        const crimeTotals = {};
    
        // Process each entry in the data
        for (const date in data) {
            for (const categoryCode in data[date]) {
                const readableCategory = type !== 'age' ? (typeCodes[type][categoryCode] || "Unknown") : categoryCode;
                data[date][categoryCode].forEach(crime => {
                    const crimeKey = crime.crimeDescription;
                    
                    // Initialize if not already done
                    if (!crimeTotals[crimeKey]) {
                        crimeTotals[crimeKey] = {};
                    }
                    if (!crimeTotals[crimeKey][readableCategory]) {
                        crimeTotals[crimeKey][readableCategory] = 0;
                    }
    
                    // Aggregate the counts
                    crimeTotals[crimeKey][readableCategory] += crime.count;
                });
            }
        }
    
        // Prepare the data in a format suitable for Recharts
        const chartData = Object.keys(crimeTotals).map(crimeDescription => {
            const entry = { crimeDescription };
            Object.keys(crimeTotals[crimeDescription]).forEach(category => {
                entry[category] = crimeTotals[crimeDescription][category];
            });
            return entry;
        });
    
        return chartData;
    }

    const title = data && data.length > 0 ? 
    `Distribution of selected crime types by ${graphDemographic} from ${startDate.toDateString()} to ${endDate.toDateString()}` : 
    "Loading graph...";
    const barTitle = graphInterval === 'daily' ? 'Summed Crimes Per Crime Type By Demographic Per Day' : 'Summed Crimes Per Crime Type By Demographic Per Month';
    const crimeTypeKeys = data.length > 0 ? Object.keys(data[0]).filter(key => key !== 'date') : [];

    const colors = [
        '#8884d8', '#82ca9d', '#ffc658', '#ff7300', '#413ea0',
        '#e6194B', '#f58231', '#ffe119', '#bfef45', '#3cb44b',
        '#42d4f4', '#4363d8', '#911eb4', '#f032e6', '#fabed4',
        '#469990', '#dcbeff', '#9A6324', '#fffac8', '#800000',
        '#aaffc3', '#000075'
    ];
    

    const getRandomColor = (index) => colors[index % colors.length];    

    return (
       <Flex direction="row" align="center" justify="center" minHeight="100vh" bg="gray.100" w="100vw">
            <Box display="flex" justifyContent="center" alignItems="center" minHeight="100vh" width="30%">
                <VStack align="start" spacing={4} border="1px solid" borderColor="gray.200" p={5} borderRadius="md" bg="white">
                    <FormControl>
                        <FormLabel>Start Date</FormLabel>
                        <DatePicker
                            selected={startDate}
                            onChange={(date) => setStartDate(date)}
                            selectsStart
                            startDate={startDate}
                            endDate={endDate}
                            maxDate={new Date('2023-12-31')}
                            minDate={new Date('2020-01-01')}
                            dateFormat="MMMM d, yyyy"
                            className="chakra-input css-0"
                            style={{border: '1px solid #E2E8F0', borderRadius: '0.375rem', padding: '0.5rem'}}
                        />
                    </FormControl>
                    <FormControl>
                        <FormLabel>End Date</FormLabel>
                        <DatePicker
                            selected={endDate}
                            onChange={(date) => setEndDate(date)}
                            selectsEnd
                            startDate={startDate}
                            endDate={endDate}
                            minDate={startDate}
                            maxDate={new Date('2023-12-31')}
                            dateFormat="MMMM d, yyyy"
                            className="chakra-input css-0"
                            style={{border: '1px solid #E2E8F0', borderRadius: '0.375rem', padding: '0.5rem'}}
                        />
                    </FormControl>
                    <FormControl>
                        <FormLabel>Demographic Select</FormLabel>
                        <Select
                            options={demographicOptions}
                            classNamePrefix="select"
                            value={selectedDemographic}
                            onChange={setSelectedDemographic}
                            styles={customStyles}
                        />
                    </FormControl>
                    <FormControl>
                        <FormLabel>Crime Type Select</FormLabel>
                        <Select
                            isMulti
                            options={crimeOptions}
                            classNamePrefix="select"
                            value={selectedCrimes}
                            onChange={setSelectedCrimes}
                            styles={customStyles}
                        />
                    </FormControl>
                    <FormControl as="fieldset">
                        <FormLabel as="legend">Interval</FormLabel>
                        <RadioGroup onChange={setInterval} value={interval}>
                            <Stack direction="row">
                                <Radio value="daily">Daily</Radio>
                                <Radio value="monthly">Monthly</Radio>
                            </Stack>
                        </RadioGroup>
                    </FormControl>
                    <Button colorScheme="blue" onClick={handleSubmit}>Submit</Button>
                </VStack>
            </Box>
            <Box width="60%" marginLeft="5%">
                {data.length === 0 ? (
                     <Text color="red">No crimes in this demographic with this type in this time frame</Text>
                ) : (
                    <Flex direction="column" align="center" justify="center">
                        <Text fontSize="xl" fontWeight="bold" mb={4}>{title}</Text>
                        <LineChart
                            width={1000}
                            height={600}
                            data={data}
                            margin={{
                                top: 5, right: 30, left: 20, bottom: 5,
                            }}
                        >
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="date" />
                            <YAxis />
                            <Tooltip />
                            <Legend />
                            {
                                // Dynamically create a Line component for each crime type
                                crimeTypeKeys.map((key, index) => (
                                    <Line 
                                        key={index} 
                                        type="monotone" 
                                        dataKey={key} 
                                        stroke={getRandomColor(index)} // Assign a color function based on index or key
                                        activeDot={{ r: 8 }}
                                    />
                                ))
                            }
                            <Brush dataKey="date" height={30} stroke="#8884d8" />
                        </LineChart>
                        <Text fontSize="xl" fontWeight="bold" mb={4}>{barTitle}</Text>
                        <ClusteredBarChart data={barGraphData}/>
                    </Flex>
                )}
            </Box>
        </Flex>
    );
}
