import React from 'react';
import { Box, Heading, Text, Link, Container } from '@chakra-ui/react';

const HomePage = () => {
    return (
        <Container maxW="container.xl" py={5}>
            <Heading as="h1" mb={4}>LA Crime InvestiGator</Heading>
            <Text fontSize="lg" mb={4}>
                Our application, LA Crime InvestiGator, is designed to provide an insightful exploration into the patterns and trends of criminal activities in Los Angeles from 2020 to 2023. This web-based platform serves as an interactive tool for users to query, visualize, and understand the dynamics of crime rates, crime types, and distributions over time and across different regions of the city.
            </Text>
            <Text fontSize="lg" mb={4}>
                The application allows users to perform complex queries to extract specific data based on crime type, location, and date range, among other filters. The application presents this information through featuring charts and graphs that highlight trends and anomalies. For example, users can identify areas with high burglary rates or observe how crime trends have evolved during the COVID-19 pandemic.
            </Text>
            <Text fontSize="lg" mb={4}>
                This application is built on a robust database that houses detailed records of every crime reported in Los Angeles from 2020 to 2023, allowing users access to a wide array of filters and query options which will help them understand all facets of crime and its distribution in LA.{' '}
                <Link href="https://www.kaggle.com/datasets/asaniczka/crimes-in-los-angeles-2020-2023?rvi=1" isExternal color="teal.500">
                    Access the database
                </Link>
            </Text>
            <Heading as="h2" size="lg" mb={4}>Query Capabilities</Heading>
            <Text fontSize="lg" mb={4}>
                <strong>Query 1:</strong> Users can analyze the evolution of crime types across various districts, examining the frequency and proportion of each crime category over time. This allows for a focused comparison within selected districts to track changes in crime composition. <Link href="/query1" color="teal.500">Explore Query 1</Link>
            </Text>
            <Text fontSize="lg" mb={4}>
                <strong>Query 2:</strong> This query explores the distribution and trends of weapon-involved crimes, detailing the types of weapons used and the frequency of such crimes across districts. It also highlights areas with lower incidences of weapon-related crimes, providing insights into safer regions. <Link href="/query2" color="teal.500">Explore Query 2</Link>
            </Text>
            <Text fontSize="lg" mb={4}>
                <strong>Query 3:</strong> Assess the impact of various crimes on victims differing in age, sex, and descent, and explore changes in these distributions over time. This query enables users to see how frequently different crimes affect diverse victim demographics, providing a deeper understanding of victimology within crime patterns. <Link href="/query3" color="teal.500">Explore Query 3</Link>
            </Text>
            <Text fontSize="lg" mb={4}>
                <strong>Query 4:</strong> Analyze discrepancies between the dates crimes were committed and reported across different crime types and districts. This query helps identify patterns of reporting delays and compare these across various districts and crime categories. <Link href="/query4" color="teal.500">Explore Query 4</Link>
            </Text>
            <Text fontSize="lg" mb={4}>
                <strong>Query 5:</strong> Investigate the association between crimes and premises over time, identifying how these relationships change. Users can explore the most frequent crime-premise correlations and observe shifts in these patterns over selected periods. <Link href="/query5" color="teal.500">Explore Query 5</Link>
            </Text>
        </Container>
    );
};

export default HomePage;
