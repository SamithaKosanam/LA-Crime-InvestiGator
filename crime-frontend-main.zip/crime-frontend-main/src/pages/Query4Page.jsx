import React, { useState, useEffect, useRef } from 'react';
import { Stack, Radio, RadioGroup, Text, Flex, Button, Box, VStack, FormControl, FormLabel } from '@chakra-ui/react';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import Select from 'react-select';
import customFetch from '../customFetch';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, Brush } from 'recharts';
import moment from 'moment';
import * as d3 from 'd3';
import CustomPieChart from '../components/CustomPieChart';

const Query4Page = () => {
    const [startDate, setStartDate] = useState(new Date(2021, 0, 1));
    const [endDate, setEndDate] = useState(new Date(2021, 11, 31));
    const [selectedAreas, setSelectedAreas] = useState([]);
    const [areaOptions, setAreaOptions] = useState([
        { value: 'option1', label: 'Option 1' },
        { value: 'option2', label: 'Option 2' },
        { value: 'option3', label: 'Option 3' },
    ]);
    const [selectedCrimes, setSelectedCrimes] = useState([]);
    const [crimeOptions, setCrimeOptions] = useState([
        { value: 'option1', label: 'Option 1' },
        { value: 'option2', label: 'Option 2' },
        { value: 'option3', label: 'Option 3' },
    ]);
    const [interval, setInterval] = useState("daily");
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(false);
    const [graphArea, setGraphArea] = useState("");
    const [graphCrimes, setGraphCrimes] = useState([]);
    const [graphBoxData, setGraphBoxData] = useState([]);
    const [graphInterval, setGraphInterval] = useState("daily");
    const svgRef = useRef(null);

    useEffect(() => {
        async function fetchAreas() {
            const response = await customFetch('/api/areas', 'GET');
            if (response.ok) {
                const data = await response.json();
                const newOptions = data.map(area => ({ value: area[1], label: area[1] }));
                setAreaOptions(newOptions);
            } else {
                // If the fetch fails, we stick with the default options set in the useState hook
                console.error('Error fetching areas. Using default options.');
            }
        }
        async function fetchCrimetypes() {
            const response = await customFetch('/api/crimeTypes', 'GET');
            if (response.ok) {
                const data = await response.json();
                const newOptions = data.map(crimeType => ({ value: crimeType[1], label: crimeType[1] }));
                setCrimeOptions(newOptions);
            } else {
                // If the fetch fails, we stick with the default options set in the useState hook
                console.error('Error fetching crimes. Using default options.');
            }
        }
        fetchAreas();
        fetchCrimetypes();
    }, []);

    useEffect(() => {
        // set the dimensions and margins of the graph
        if(graphBoxData != []) {
            d3.select(svgRef.current).selectAll("*").remove();

            const width = 900;
            const height = 500;
            const marginTop = 40;
            const marginRight = 40;
            const marginBottom = 40;
            const marginLeft = 80;
            const n = graphBoxData.length > 0 ? graphBoxData.length : 12;
            const numCrimes = selectedCrimes.length;
            graphBoxData.sort((a, b) => new Date(a.date) - new Date(b.date));
            const newSelectedCrimes = selectedCrimes.slice().sort((a, b) => a.value.localeCompare(b.value));

            const colorScale = d3.scaleSequential()
                .domain([0, 100])
                .interpolator(d3.interpolateRainbow);

            const x = d3.scaleBand()
                .domain(graphBoxData.map(d => d.date))
                .range([marginLeft, width-marginRight])
                .padding(0.1); 

            const y = d3.scaleLinear()
                .domain([0, d3.max(graphBoxData, d => d.maximum)])
                .range([height-marginBottom, marginTop]);

            const svg = d3.create("svg")
                .attr("width", width)
                .attr("height", height)
                .attr("viewBox", [0, 0, width, height])
                .attr("style", "max-width: 100%; height: auto; font: 10px sans-serif;")
                .attr("text-anchor", "middle");

            svg.append("text")
                .attr("transform", `translate(${width / 2}, ${marginTop / 2})`) // Position at the top center
                .style("text-anchor", "middle")
                .style("font-weight", "bold")
                .style("font-size", "15px")
                .text(`Box Plot of Report Time Discrepancy (Days) Over Time in ${graphArea} from ${startDate.toDateString()} to ${endDate.toDateString()} `);

            svg.append("text")
                .attr("transform", `translate(${width / 2}, ${height})`)
                .style("text-anchor", "middle")
                .text("Date");
    
            svg.append("text")
                .attr("transform", `rotate(-90) translate(${-height / 2}, ${marginLeft - 40})`) // Position at the left center and rotate for vertical text
                .style("text-anchor", "middle")
                .text("Time Discrepancy (Days)");

            const g = svg.append("g")
                .selectAll("g")
                .data(graphBoxData)
                .join("g") 
            
            //Line
            g.append("path")
                .attr("stroke", d => {
                    const colorIndex = 100 - newSelectedCrimes.findIndex(obj => obj.value === d.crimeDescription) * 100 / numCrimes;
                    const color = colorScale(colorIndex);
                    return d3.rgb(color).toString();
                })
                .attr("d", d => {
                    const index = newSelectedCrimes.findIndex(obj => obj.value === d.crimeDescription);
                    const increment = x.bandwidth() / (1+numCrimes);
                    const middle = x(d.date) + increment * (index+1);
                    return `
                        M${(middle)},${y(d.range[1])}
                        V${y(d.range[0])}
                    `;
                });
            
            //Quantiles
            g.append("path")
                .attr("fill", d => {
                    const colorIndex = 100 - newSelectedCrimes.findIndex(obj => obj.value === d.crimeDescription) * 100 / numCrimes;
                    const color = colorScale(colorIndex);
                    const hslColor = d3.hsl(color);
                    hslColor.l += 0.15
                    return hslColor.toString();
                })
                .attr("d", d => {
                    const index = newSelectedCrimes.findIndex(obj => obj.value === d.crimeDescription);
                    const increment = x.bandwidth() / (1+numCrimes);
                    const middle = x(d.date) + increment * (index+1);
                    const boxPlotWidth = 15 / newSelectedCrimes.length;
                    const left = middle - boxPlotWidth;
                    const right = middle + boxPlotWidth;
                    return `
                    M${left},${y(d.quartiles[2])}
                    H${right}
                    V${y(d.quartiles[0])}
                    H${left}
                    Z
                `});
            
                //Median
                g.append("path")
                    .attr("stroke", d => {
                        const colorIndex = 100 - newSelectedCrimes.findIndex(obj => obj.value === d.crimeDescription) * 100 / numCrimes;
                        const color = colorScale(colorIndex);
                        const hslColor = d3.hsl(color);
                        hslColor.l -= 0.2;
                        return hslColor.toString();
                    })
                    .attr("stroke-width", 2)
                    .attr("d", d => {
                        const index = newSelectedCrimes.findIndex(obj => obj.value === d.crimeDescription);
                        const increment = x.bandwidth() / (1+numCrimes);
                        const middle = x(d.date) + increment * (index+1);
                        const boxPlotWidth = 15 / newSelectedCrimes.length;
                        const left = middle - boxPlotWidth;
                        const right = middle + boxPlotWidth;
                        return `
                        M${left},${y(d.quartiles[1])}
                        H${right}
                    `});
                
                // Average
                g.append("circle")
                    .attr("r",3)
                    .attr('fill', d => {
                        const colorIndex = 100 - newSelectedCrimes.findIndex(obj => obj.value === d.crimeDescription) * 100 / numCrimes;
                        const color = colorScale(colorIndex);
                        const hslColor = d3.hsl(color);
                        hslColor.h += 0.5;
                        hslColor.l -= 0.2;
                        return hslColor.toString();
                    })
                    .attr("cx", d => {
                        const index = newSelectedCrimes.findIndex(obj => obj.value === d.crimeDescription);
                        const increment = x.bandwidth() / (1+numCrimes);
                        const middle = x(d.date) + increment * (index+1);
                        return middle;
                    })
                    .attr("cy", d => {
                        return y(d.average_time_difference_days);
                    })
            
            // Append the x axis based on interval
            if(interval === "daily") {
                svg.append("g")
                .attr("transform", `translate(0,${height - marginBottom})`)
                .call(d3.axisBottom(x).ticks(12).tickFormat(""));
            } else {
                svg.append("g")
                .attr("transform", `translate(0,${height - marginBottom})`)
                .call(d3.axisBottom(x).ticks(n).tickSizeOuter(0));
            }

            // Append the y axis
            svg.append("g")
            .attr("transform", `translate(${marginLeft},0)`)
            .call(d3.axisLeft(y).ticks(null, "s"))
            .call(g => g.select(".domain").remove());
            
            if (svgRef.current) {
                svgRef.current.appendChild(svg.node());
            }
        }
    }, [graphBoxData]);

    // Define custom styles for react-select based on Chakra UI's design system
    const customStyles = {
        control: (provided) => ({
            ...provided,
            borderRadius: '0.375rem', // 6px
            borderColor: '#E2E8F0',
            boxShadow: 'sm',
            minHeight: '32px',
            '&:hover': {
                borderColor: '#CBD5E0',
            },
        }),
        multiValue: (provided) => ({
            ...provided,
            backgroundColor: '#EBF8FF',
        }),
        multiValueLabel: (provided) => ({
            ...provided,
            color: '#1A202C',
        }),
        multiValueRemove: (provided) => ({
            ...provided,
            color: '#718096',
            '&:hover': {
                backgroundColor: '#E53E3E',
                color: 'white',
            },
        }),
    };

    const handleSubmit = async () => {
        setLoading(true);
        const formatDateString = (date) => {
            const year = date.getFullYear();
            const month = (`0${date.getMonth() + 1}`).slice(-2); // Months are 0-indexed, add 1 to get the correct month
            const day = (`0${date.getDate()}`).slice(-2);
            return `${year}-${month}-${day}`;
        };
    
        const formattedStartDate = formatDateString(startDate);
        const formattedEndDate = formatDateString(endDate);

        const queryParams = new URLSearchParams({
            startDate: formattedStartDate,
            endDate: formattedEndDate,
            areas: selectedAreas.value,
            interval: interval
        });
        
        // Append 'crimeDescription' parameter for each selected crime description
        selectedCrimes.forEach(crime => queryParams.append('crimeDescriptions', crime.value));
        
        setGraphArea(selectedAreas.value);
        console.log("setGraphArea", graphArea);
        setGraphCrimes(selectedCrimes.map(crime => crime.value));
        setGraphInterval(interval);
        try {
            const response = await customFetch(`/api/query4?${queryParams}`, 'GET');
            if (response.ok) {
                const jsonData = await response.json();
                console.log(jsonData);
                const processedData = processDataForGraph(jsonData, interval);
                setData(processedData); // This should now correctly update the graph
                const boxData = processDataForBox(jsonData, interval);
                console.log("BoxData", boxData);
                setGraphBoxData(boxData);
            } else {
                console.error('Failed to fetch data');
                setData([]); // Ensure to clear data or set to a default state indicating no results
            }            
        } catch (error) {
            console.error('Fetch error:', error);
        } finally {
            setLoading(false);
        }
    };
    
    const processDataForGraph = (jsonData, interval) => {
        let graphData = [];
        let crimeTypesSet = new Set();
    
        // Identify all unique crime types
        Object.values(jsonData).forEach(areaData => {
            Object.values(areaData).forEach(crimes => {
                crimes.forEach(crime => crimeTypesSet.add(crime.crimeDescription));
            });
        });
    
        // Prepare date range for iteration
        const allPeriods = Object.keys(jsonData).sort();
        const format = interval === 'daily' ? 'YYYY-MM-DD' : 'YYYY-MM';
        const addUnit = interval === 'daily' ? 'days' : 'months';
        let currentDate = allPeriods[0];
        const endDate = allPeriods[allPeriods.length - 1];
    
        while (currentDate <= endDate) {
            const periodData = jsonData[currentDate] || {};
    
            crimeTypesSet.forEach(crimeType => {
                const crimeData = periodData[graphArea]?.find(cd => cd.crimeDescription === crimeType);
                const dataKey = `crimeType_${crimeType.replace(/[^a-zA-Z0-9]/g, "_")}`;
    
                if (!graphData[currentDate]) graphData[currentDate] = { date: currentDate };
    
                graphData[currentDate][dataKey] = crimeData ? crimeData.average_time_difference_days : 0;
            });
    
            // Move to the next day or month
            currentDate = moment(currentDate, format).add(1, addUnit).format(format);
        }
    
        // Convert object back to array for charting
        return Object.values(graphData);
    };

    const processDataForBox = (jsonData, interval) => {
        let boxData = [];
        for (const [date, dateData] of Object.entries(jsonData)) {
            for (const [area, areaData] of Object.entries(dateData)) {
                areaData.forEach(crime => {
                    const newObject = {
                        date: date,
                        area: area,
                        crimeDescription: crime.crimeDescription,
                        average_time_difference_days: crime.average_time_difference_days,
                        minimum: crime.minimum,
                        first_quartile: crime.first_quartile,
                        median: crime.median,
                        third_quartile: crime.third_quartile,
                        maximum: crime.maximum,
                        quartiles: [crime.first_quartile,crime.median,crime.third_quartile],
                        range: [crime.minimum,crime.maximum],
                        x0: crime.minimum,
                        x1: crime.maximum,
                    };
                    boxData.push(newObject);
                });
            }
        }
        return boxData;
    }
    
    const title = data && data.length > 0 ? 
    `Average Report Time Discrepancy (Days) in ${graphArea} from ${startDate.toDateString()} to ${endDate.toDateString()}` : 
    "Loading graph...";
    const crimeTypeKeys = data.length > 0 ? Object.keys(data[0]).filter(key => key !== 'date') : [];

    const colors = [
        '#8884d8', '#82ca9d', '#ffc658', '#ff7300', '#413ea0',
        '#e6194B', '#f58231', '#ffe119', '#bfef45', '#3cb44b',
        '#42d4f4', '#4363d8', '#911eb4', '#f032e6', '#fabed4',
        '#469990', '#dcbeff', '#9A6324', '#fffac8', '#800000',
        '#aaffc3', '#000075'
    ];
    

    const getRandomColor = (index) => colors[index % colors.length];    

    return (
       <Flex direction="row" align="center" justify="center" minHeight="100vh" bg="gray.100" w="100vw">
            <Box display="flex" justifyContent="center" alignItems="center" minHeight="100vh" width="30%">
                <VStack align="start" spacing={4} border="1px solid" borderColor="gray.200" p={5} borderRadius="md" bg="white">
                    <FormControl>
                        <FormLabel>Start Date</FormLabel>
                        <DatePicker
                            selected={startDate}
                            onChange={(date) => setStartDate(date)}
                            selectsStart
                            startDate={startDate}
                            endDate={endDate}
                            maxDate={new Date('2023-12-31')}
                            minDate={new Date('2020-01-01')}
                            dateFormat="MMMM d, yyyy"
                            className="chakra-input css-0"
                            style={{border: '1px solid #E2E8F0', borderRadius: '0.375rem', padding: '0.5rem'}}
                        />
                    </FormControl>
                    <FormControl>
                        <FormLabel>End Date</FormLabel>
                        <DatePicker
                            selected={endDate}
                            onChange={(date) => setEndDate(date)}
                            selectsEnd
                            startDate={startDate}
                            endDate={endDate}
                            minDate={startDate}
                            maxDate={new Date('2023-12-31')}
                            dateFormat="MMMM d, yyyy"
                            className="chakra-input css-0"
                            style={{border: '1px solid #E2E8F0', borderRadius: '0.375rem', padding: '0.5rem'}}
                        />
                    </FormControl>
                    <FormControl>
                        <FormLabel>Area Select</FormLabel>
                        <Select
                            options={areaOptions}
                            classNamePrefix="select"
                            value={selectedAreas}
                            onChange={setSelectedAreas}
                            styles={customStyles}
                        />
                    </FormControl>
                    <FormControl>
                        <FormLabel>Crime Type Select</FormLabel>
                        <Select
                            isMulti
                            options={crimeOptions}
                            classNamePrefix="select"
                            value={selectedCrimes}
                            onChange={setSelectedCrimes}
                            styles={customStyles}
                        />
                    </FormControl>
                    <FormControl as="fieldset">
                        <FormLabel as="legend">Interval</FormLabel>
                        <RadioGroup onChange={setInterval} value={interval}>
                            <Stack direction="row">
                                <Radio value="daily">Daily</Radio>
                                <Radio value="monthly">Monthly</Radio>
                            </Stack>
                        </RadioGroup>
                    </FormControl>
                    <Button colorScheme="blue" onClick={handleSubmit}>Submit</Button> {/* Add this Button */}
                </VStack>
            </Box>
            <Box width="60%" marginLeft="5%">
                {data.length === 0 ? (
                     <Text color="red">No crimes in this area with this type in this time frame</Text>
                ) : (
                    <Flex direction="column" align="center" justify="center">
                        <Text fontSize="xl" fontWeight="bold" mb={4}>{title}</Text>
                        <LineChart
                            width={1000}
                            height={600}
                            data={data}
                            margin={{
                                top: 5, right: 30, left: 20, bottom: 5,
                            }}
                        >
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="date" />
                            <YAxis />
                            <Tooltip />
                            <Legend />
                            {
                                // Dynamically create a Line component for each crime type
                                crimeTypeKeys.map((key, index) => (
                                    <Line 
                                        key={index} 
                                        type="monotone" 
                                        dataKey={key} 
                                        stroke={getRandomColor(index)} // Assign a color function based on index or key
                                        activeDot={{ r: 8 }}
                                    />
                                ))
                            }
                            <Brush dataKey="date" height={30} stroke="#8884d8" />
                        </LineChart>
                    </Flex>
                )}
                {graphBoxData.length === 0? (
                     <div></div>
                ) : (
                    <svg ref={svgRef} width={980} height={580}></svg>
                )}
            </Box>
        </Flex>
    );
}

export default Query4Page;