const { getConnection } = require('./db');
const { get } = require('./query');
const { getVictimInfoString, query1Daily, query1Monthly, getAreasQuery, getCrimeTypesQuery, query2Daily, query2Monthly, query3Daily, query3Monthly, getWeaponDescriptionsQuery, query4Monthly, query4Daily, query5Daily, query5Monthly, getPremisesQuery} = require('./queryStrings');



async function queryDatabase(req, res) {
  try {
    const connection = getConnection();
    const result = await connection.execute(`SELECT * FROM AREA`);
    res.status(200).json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(400).send('Error executing query');
  }
}

function transformData(data) {
  const groupedData = {};
  data.forEach(([areaName, crimeDescription, date, count, avg_latitude, avg_longitude, percentage]) => {
      if (!groupedData[date]) {
          groupedData[date] = {};
      }

      if (!groupedData[date][areaName]) {
          groupedData[date][areaName] = [];
      }

      groupedData[date][areaName].push({
          crimeDescription,
          count,
          percentage,
          avg_latitude,
          avg_longitude
      });
  });

  return groupedData
}

function transformQuery2Data(data) {
  const groupedData = {};
  data.forEach(([areaName, weaponDescription, date, count, rank, total_count, incidence_status, percentage]) => {
      if (!groupedData[date]) {
          groupedData[date] = {};
      }

      if (!groupedData[date][areaName]) {
          groupedData[date][areaName] = [];
      }

      groupedData[date][areaName].push({
          weaponDescription,
          count,
          rank,
          total_count,
          percentage
      });
  });

  return groupedData
}


function transformQuery3Data(rows) {
  const transformed = {};

  rows.forEach(([crimeDescription, date, type, count]) => {
      if (!transformed[date]) {
          transformed[date] = {};
      }

      if (!transformed[date][type]) {
          transformed[date][type] = [];
      }

      let existingCrime = transformed[date][type].find(crime => crime.crimeDescription === crimeDescription);

      if (existingCrime) {
          existingCrime.count += count;
      } else {
          transformed[date][type].push({
              crimeDescription: crimeDescription,
              count: count
          });
      }
  });

  return transformed;
}




function transformQuery4Data(data) {
  const groupedData = {};
  data.forEach(([areaName, crimeDescription, date, average_time_difference_days, minimum, first_quartile, median, third_quartile, maximum, interQuantileRange]) => {
      if (!groupedData[date]) {
          groupedData[date] = {};
      }

      if (!groupedData[date][areaName]) {
          groupedData[date][areaName] = [];
      }

      groupedData[date][areaName].push({
          crimeDescription,
          average_time_difference_days,
          minimum,
          first_quartile,
          median,
          third_quartile,
          maximum,
          interQuantileRange
      });
  });
  return groupedData
}


function transformQuery5Data(data) {
  const groupedData = {};
  console.log(data)
  data.forEach(([areaName, crimeDescription, date, count, avg_latitude, avg_longitude, percentage]) => {
      if (!groupedData[date]) {
          groupedData[date] = {};
      }

      if (!groupedData[date][areaName]) {
          groupedData[date][areaName] = [];
      }

      groupedData[date][areaName].push({
          crimeDescription,
          count,
          percentage,
          avg_latitude,
          avg_longitude
      });
  });

  return groupedData
}

const validateDate = (date, startYear = 2020, endYear = 2023) => {
  const dateObj = new Date(date);
  const year = dateObj.getFullYear();
  return dateObj instanceof Date && !isNaN(dateObj) && year >= startYear && year <= endYear;
};

//Query 1: finding the crimes per area over time and separating by crime type
async function query1CrimeTypes(req, res) {
  try {
    let { startDate, endDate, areas, crimeDescriptions, interval } = req.query; // Assuming these are passed as query parameters
    console.log(startDate, endDate, areas, crimeDescriptions)
    // Basic validation
    if (!validateDate(startDate) || !validateDate(endDate) || new Date(startDate) > new Date(endDate)) {
        return res.status(400).send('Invalid start or end date');
    }
    console.log(crimeDescriptions, "crimeDescriptions", typeof crimeDescriptions)
    if (typeof crimeDescriptions === 'string') {
      crimeDescriptions = [crimeDescriptions]
    }
    const areaArray = areas ? areas.split(',') : []; 
    const connection = await getConnection();
    let result = null
    if (interval === 'daily') {
      result = await connection.execute(query1Daily(startDate, endDate, areaArray, crimeDescriptions));
    } else {
      result = await connection.execute(query1Monthly(startDate, endDate, areaArray, crimeDescriptions));
    }
    ret = transformData(result.rows);
    res.status(200).json(ret);
  } catch (err) {
    console.error(err);
    res.status(400).json({ error: err.message });
  }
}
//Query 2: trends of weapon-involed crimes by prevalence of specific weapon types
async function query2WeaponTypes(req, res) {
  try {
    let { startDate, endDate, areas, weaponDescriptions, interval } = req.query; // Assuming these are passed as query parameters
    // Basic validation
    if (!validateDate(startDate) || !validateDate(endDate) || new Date(startDate) > new Date(endDate)) {
        return res.status(400).send('Invalid start or end date');
    }
    //console.log(weaponDescriptions, "weaponDescriptions", typeof weaponDescriptions)
    if (typeof weaponDescriptions === 'string') {
      weaponDescriptions = [weaponDescriptions]
    }
    const areaArray = areas ? areas.split(',') : []; 
    const connection = await getConnection();
    let result = null
    if (interval === 'daily') {
      result = await connection.execute(query2Daily(startDate, endDate, areaArray, weaponDescriptions));
    } else {
      result = await connection.execute(query2Monthly(startDate, endDate, areaArray, weaponDescriptions));
    }
    ret = transformQuery2Data(result.rows);
    res.status(200).json(ret);
  } catch (err) {
    console.error(err);
    res.status(400).json({ error: err.message });
  }
}


// Query 3: Victim Demographics
async function query3VictimSex(req, res) {
  try {
    let { startDate, endDate, crimeDescriptions, interval, type } = req.query; // Assuming these are passed as query parameters

    // Basic validation of dates
    if (!validateDate(startDate) || !validateDate(endDate) || new Date(startDate) > new Date(endDate)) {
      return res.status(400).send('Invalid start or end date');
    }

    // Check if crimeDescriptions is a string, if so, convert it to an array
    if (typeof crimeDescriptions === 'string') {
      crimeDescriptions = [crimeDescriptions]
    }

    const connection = await getConnection();
    let result = null;
    console.log("query babe", query3Daily(startDate, endDate, crimeDescriptions, type))
    // Choose query based on interval (daily or monthly)
    if (interval === 'daily') {
      result = await connection.execute(query3Daily(startDate, endDate, crimeDescriptions, type));
    } else {
      result = await connection.execute(query3Monthly(startDate, endDate, crimeDescriptions, type));
    }

    // Transform the data
    const transformedData = transformQuery3Data(result.rows);

    // Send transformed data as response
    res.status(200).json(transformedData);
  } catch (err) {
     console.error(err);
     res.status(400).json({ error: err.message });
  }
}

//Query 4: Time Differences
async function query4TimeDifferences(req, res) {
  console.log("Query 4 being run");
  try {
    let { startDate, endDate, areas, crimeDescriptions, interval } = req.query; // Assuming these are passed as query parameters
    console.log(startDate, endDate, areas, crimeDescriptions)
    // Basic validation
    if (!validateDate(startDate) || !validateDate(endDate) || new Date(startDate) > new Date(endDate)) {
        return res.status(400).send('Invalid start or end date');
    }
    console.log(crimeDescriptions, "crimeDescriptions", typeof crimeDescriptions)
    if (typeof crimeDescriptions === 'string') {
      crimeDescriptions = [crimeDescriptions]
    }
    const areaArray = areas ? areas.split(',') : []; 
    const connection = await getConnection();
    let result = null
    if (interval === 'daily') {
      result = await connection.execute(query4Daily(startDate, endDate, areaArray, crimeDescriptions));
    } else {
      result = await connection.execute(query4Monthly(startDate, endDate, areaArray, crimeDescriptions));
    }
    ret = transformQuery4Data(result.rows);
    res.status(200).json(ret);
  } catch (err) {
    console.error(err);
    res.status(400).json({ error: err.message });
  }
}


async function getVictimInfo(req, res) {
  try {
    const connection = await getConnection();
    console.log("QUERY STRING BABE", getVictimInfoString)
    result = await connection.execute(getVictimInfoString);
    res.status(200).json(result)
  } catch (error) {
    console.error(error);
    res.status(400).json({ error: error.message });
  }
}

// Query 5: Crime Premise
async function query5Premise(req,res){
  // Premise query
  try{
    let { startDate, endDate, premise, crimeDescriptions, interval } = req.query; // Assuming these are passed as query parameters
    console.log(startDate, endDate, premise, crimeDescriptions, interval)

    if (!validateDate(startDate) || !validateDate(endDate) || new Date(startDate) > new Date(endDate)) {
        return res.status(400).send('Invalid start or end date');
    }

    const connection = await getConnection();
    let result = null;

    if (interval === 'daily') {
      result = await connection.execute(query5Daily(startDate, endDate, premise, crimeDescriptions));
    } else {
      result = await connection.execute(query5Monthly(startDate, endDate, premise, crimeDescriptions));
    }
    ret = transformQuery5Data(result.rows);
    res.status(200).json(ret);

  }catch(err){
    console.error(err);
    res.status(400).json({ error: err.message });
  }
}

async function getPremises(req, res){
  try {
    const connection = getConnection();
    const result = await connection.execute(getPremisesQuery);
    res.status(200).json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(400).send('Error executing query');
  }
}

async function getAreas(req, res) {
  try {
    const connection = getConnection();
    const result = await connection.execute(getAreasQuery);
    res.status(200).json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(400).send('Error executing query');
  }
}

async function getCrimeTypes(req, res) {
  try {
    const connection = getConnection();
    const result = await connection.execute(getCrimeTypesQuery);
    res.status(200).json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(400).send('Error executing query');
  }
}

async function getWeaponDescriptions(req, res) {
  try {
    const connection = getConnection();
    const result = await connection.execute(getWeaponDescriptionsQuery);
    res.status(200).json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(400).send('Error executing query');
  }
}

module.exports = { getVictimInfo, getCrimeTypes, queryDatabase, query1CrimeTypes, getAreas, query2WeaponTypes, query3VictimSex, getWeaponDescriptions, query4TimeDifferences, query5Premise, getPremises};

