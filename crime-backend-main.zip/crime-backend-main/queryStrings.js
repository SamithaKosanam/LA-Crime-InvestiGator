const getAreasQuery = 'SELECT area_code,area_name FROM Area ORDER BY area_name ASC';
const getCrimeTypesQuery = `
    SELECT crime_code, crime_description
    FROM CrimeType NATURAL JOIN Crime 
    GROUP BY crime_code, crime_description 
    ORDER BY COUNT(*) DESC
`;
const getWeaponDescriptionsQuery = `
    SELECT weapon_description
    FROM Crime
        LEFT JOIN Weapon ON Crime.weapon_code = Weapon.weapon_code
    WHERE weapon_description IS NOT NULL
    GROUP BY weapon_description 
    ORDER BY COUNT(*) DESC
`;
const getPremisesQuery =`
SELECT premise_code, premise_description
FROM Premise NATURAL JOIN Crime 
GROUP BY premise_code, premise_description 
ORDER BY COUNT(*) DESC
`;

const query1Monthly = (startDate, endDate, areas, crimeDescriptions) => `
WITH MonthlyCrimeCounts AS (
    SELECT 
        a.area_name,
        ct.crime_description,
        TO_CHAR(c.date_committed, 'YYYY-MM') AS crime_month,
        COUNT(*) AS crime_count,
        ROUND(AVG(c.latitude),9) AS avg_latitude,
        ROUND(AVG(c.longitude),9) AS avg_longitude
    FROM 
        Crime c
        JOIN CrimeType ct ON c.crime_code = ct.crime_code
        JOIN Area a ON c.area_code = a.area_code
    WHERE 
        c.date_committed BETWEEN TO_DATE('${startDate}', 'YYYY-MM-DD') AND TO_DATE('${endDate}', 'YYYY-MM-DD')
        ${crimeDescriptions.length > 0 ? `AND ct.crime_description IN (${crimeDescriptions.map(crime => `'${crime}'`).join(", ")})` : ''}
        ${areas.length > 0 ? `AND a.area_name IN (${areas.map((area, index) => `'${area}'`).join(", ")})` : ''}
    GROUP BY 
        a.area_name,
        ct.crime_description,
        TO_CHAR(c.date_committed, 'YYYY-MM')
),
TotalMonthlyCrimes AS (
    SELECT 
        area_name,
        crime_month,
        SUM(crime_count) AS total_crimes
    FROM 
        MonthlyCrimeCounts
    GROUP BY 
        area_name,
        crime_month
)
SELECT 
    mcc.area_name,
    mcc.crime_description,
    mcc.crime_month,
    mcc.crime_count,
    mcc.avg_latitude,
    mcc.avg_longitude,
    ROUND(mcc.crime_count / tmc.total_crimes * 100, 2) AS crime_proportion_percentage
FROM 
    MonthlyCrimeCounts mcc
    JOIN TotalMonthlyCrimes tmc ON mcc.area_name = tmc.area_name AND mcc.crime_month = tmc.crime_month
ORDER BY 
    mcc.area_name,
    mcc.crime_month,
    mcc.crime_count DESC
`;
const query1Daily = (startDate, endDate, areas, crimeDescriptions) => `
WITH DailyCrimeCounts AS (
    SELECT 
        a.area_name,
        ct.crime_description,
        TO_CHAR(c.date_committed, 'YYYY-MM-DD') AS crime_date,
        COUNT(*) AS crime_count,
        ROUND(AVG(c.latitude),9) AS avg_latitude,
        ROUND(AVG(c.longitude),9) AS avg_longitude
    FROM 
        Crime c
        JOIN CrimeType ct ON c.crime_code = ct.crime_code
        JOIN Area a ON c.area_code = a.area_code
    WHERE 
        c.date_committed BETWEEN TO_DATE('${startDate}', 'YYYY-MM-DD') AND TO_DATE('${endDate}', 'YYYY-MM-DD')
        ${crimeDescriptions.length > 0 ? `AND ct.crime_description IN (${crimeDescriptions.map(crime => `'${crime}'`).join(", ")})` : ''}
        ${areas.length > 0 ? `AND a.area_name IN (${areas.map(area => `'${area}'`).join(", ")})` : ''}
    GROUP BY 
        a.area_name,
        ct.crime_description,
        TO_CHAR(c.date_committed, 'YYYY-MM-DD')
),
TotalDailyCrimes AS (
    SELECT 
        area_name,
        crime_date,
        SUM(crime_count) AS total_crimes
    FROM 
        DailyCrimeCounts
    GROUP BY 
        area_name,
        crime_date
)
SELECT 
    dcc.area_name,
    dcc.crime_description,
    dcc.crime_date,
    dcc.crime_count,
    dcc.avg_latitude,
    dcc.avg_longitude,
    ROUND(dcc.crime_count / tdc.total_crimes * 100, 2) AS crime_proportion_percentage
FROM 
    DailyCrimeCounts dcc
    JOIN TotalDailyCrimes tdc ON dcc.area_name = tdc.area_name AND dcc.crime_date = tdc.crime_date
ORDER BY 
    dcc.area_name,
    dcc.crime_date,
    dcc.crime_count DESC
`;
const query2Daily = (startDate, endDate, areas, weaponDescriptions) => `
WITH WeaponCounts AS (
    SELECT
        A.area_name,
        W.weapon_description,
        TO_CHAR(C.date_committed, 'YYYY-MM-DD') AS crime_day,
        COUNT(*) AS weapon_count
    FROM
        Crime C
    INNER JOIN
        Area A ON C.area_code = A.area_code
    LEFT JOIN
        Weapon W ON C.weapon_code = W.weapon_code
    WHERE
        C.date_committed BETWEEN TO_DATE('${startDate}', 'YYYY-MM-DD') AND TO_DATE('${endDate}', 'YYYY-MM-DD')
        AND W.weapon_description IS NOT NULL
        ${areas.length > 0 ? `AND A.area_name IN (${areas.map(area => `'${area}'`).join(", ")})` : ''}
        ${weaponDescriptions.length > 0 ? `AND W.weapon_description IN (${weaponDescriptions.map(weapon => `'${weapon}'`).join(", ")})` : ''}
    GROUP BY
        A.area_name,
        W.weapon_description,
        TO_CHAR(C.date_committed, 'YYYY-MM-DD')
),
DistrictWeaponCounts AS (
    SELECT
        area_name,
        weapon_description,
        crime_day,
        weapon_count,
        RANK() OVER(PARTITION BY area_name ORDER BY weapon_count DESC) AS weapon_rank
    FROM
        WeaponCounts
),
DistrictTotalCounts AS (
    SELECT
        area_name,
        crime_day,
        SUM(weapon_count) AS total_weapon_count
    FROM
        WeaponCounts
    GROUP BY
        area_name,
        crime_day
),
DistrictsWithIncidence AS (
    SELECT
        DTC.area_name,
        DTC.crime_day,
        SUM(DTC.total_weapon_count) AS total_weapon_count,
        CASE
            WHEN SUM(DTC.total_weapon_count) < 0.33 * MAX(SUM(DTC.total_weapon_count)) OVER (PARTITION BY DTC.area_name) THEN 'low_incidence'
            WHEN SUM(DTC.total_weapon_count) < 0.66 * MAX(SUM(DTC.total_weapon_count)) OVER (PARTITION BY DTC.area_name) THEN 'medium_incidence'
            ELSE 'high_incidence'
        END AS incidence_status
    FROM
        DistrictTotalCounts DTC
    GROUP BY
        DTC.area_name,
        DTC.crime_day
)
SELECT
    DWC.area_name,
    DWC.weapon_description,
    DWC.crime_day,
    DWC.weapon_count,
    DWC.weapon_rank,
    DTC.total_weapon_count,
    DWI.incidence_status,
    ROUND(DWC.weapon_count / DTC.total_weapon_count * 100, 2) AS weapon_proportion_percentage
FROM
    DistrictWeaponCounts DWC
INNER JOIN
    DistrictTotalCounts DTC ON DWC.area_name = DTC.area_name AND DWC.crime_day = DTC.crime_day
INNER JOIN
    DistrictsWithIncidence DWI ON DWC.area_name = DWI.area_name AND DWC.crime_day = DWI.crime_day
ORDER BY
    DWC.area_name,
    DWC.weapon_rank
`;
const query2Monthly = (startDate, endDate, areas, weaponDescriptions) => `
WITH WeaponCounts AS (
    SELECT
        A.area_name,
        W.weapon_description,
        TO_CHAR(C.date_committed, 'YYYY-MM') AS crime_month,
        COUNT(*) AS weapon_count
    FROM
        Crime C
    INNER JOIN
        Area A ON C.area_code = A.area_code
    LEFT JOIN
        Weapon W ON C.weapon_code = W.weapon_code
    WHERE
        C.date_committed BETWEEN TO_DATE('${startDate}', 'YYYY-MM-DD') AND TO_DATE('${endDate}', 'YYYY-MM-DD')
        AND W.weapon_description IS NOT NULL
        ${areas.length > 0 ? `AND A.area_name IN (${areas.map(area => `'${area}'`).join(", ")})` : ''}
        ${weaponDescriptions.length > 0 ? `AND W.weapon_description IN (${weaponDescriptions.map(weapon => `'${weapon}'`).join(", ")})` : ''}
    GROUP BY
        A.area_name,
        W.weapon_description,
        TO_CHAR(C.date_committed, 'YYYY-MM')
),
DistrictWeaponCounts AS (
    SELECT
        area_name,
        weapon_description,
        crime_month,
        weapon_count,
        RANK() OVER(PARTITION BY area_name ORDER BY weapon_count DESC) AS weapon_rank
    FROM
        WeaponCounts
),
DistrictTotalCounts AS (
    SELECT
        area_name,
        crime_month,
        SUM(weapon_count) AS total_weapon_count
    FROM
        WeaponCounts
    GROUP BY
        area_name,
        crime_month
),
DistrictsWithIncidence AS (
    SELECT
        DTC.area_name,
        DTC.crime_month,
        SUM(DTC.total_weapon_count) AS total_weapon_count,
        CASE
            WHEN SUM(DTC.total_weapon_count) < 0.33 * MAX(SUM(DTC.total_weapon_count)) OVER (PARTITION BY DTC.area_name) THEN 'low_incidence'
            WHEN SUM(DTC.total_weapon_count) < 0.66 * MAX(SUM(DTC.total_weapon_count)) OVER (PARTITION BY DTC.area_name) THEN 'medium_incidence'
            ELSE 'high_incidence'
        END AS incidence_status
    FROM
        DistrictTotalCounts DTC
    GROUP BY
        DTC.area_name,
        DTC.crime_month
)
SELECT
    DWC.area_name,
    DWC.weapon_description,
    DWC.crime_month,
    DWC.weapon_count,
    DWC.weapon_rank,
    DTC.total_weapon_count,
    DWI.incidence_status,
    ROUND(DWC.weapon_count / DTC.total_weapon_count * 100, 2) AS weapon_proportion_percentage
FROM
    DistrictWeaponCounts DWC
INNER JOIN
    DistrictTotalCounts DTC ON DWC.area_name = DTC.area_name AND DWC.crime_month = DTC.crime_month
INNER JOIN
    DistrictsWithIncidence DWI ON DWC.area_name = DWI.area_name AND DWC.crime_month = DWI.crime_month
ORDER BY
    DWC.area_name,
    DWC.weapon_rank
`;


const getVictimInfoString = 'SELECT DISTINCT(descent) AS descents FROM Victim;'


const query3Monthly = (startDate, endDate, crimeDescriptions, type='descent') => {
    let groupByClause = '';
    let selectClause = '';
    let finalSelect = '';
    switch (type) {
        case 'age':
            selectClause = `
                ct.crime_description,
                TO_CHAR(c.date_committed, 'YYYY-MM') AS crime_month,
                TRUNC((EXTRACT(YEAR FROM SYSDATE) - v.age) / 10) * 10 AS age_group,
            `;
            groupByClause = `
                ct.crime_description,
                TO_CHAR(c.date_committed, 'YYYY-MM'),
                TRUNC((EXTRACT(YEAR FROM SYSDATE) - v.age) / 10) * 10
            `;
            finalSelect = `
                vc.crime_description,
                vc.crime_month,
                vc.age_group,
                vc.victim_count
            `
            break;
        case 'sex':
            selectClause = `
                ct.crime_description,
                v.sex,
                TO_CHAR(c.date_committed, 'YYYY-MM') AS crime_month,
            `;
            groupByClause = `
                ct.crime_description,
                v.sex,
                TO_CHAR(c.date_committed, 'YYYY-MM')
            `;
            finalSelect = `
                vc.crime_description,
                vc.crime_month,
                vc.sex,
                vc.victim_count
            `
            break;
        case 'descent':
            selectClause = `
                ct.crime_description,
                v.descent,
                TO_CHAR(c.date_committed, 'YYYY-MM') AS crime_month,
            `;
            groupByClause = `
                ct.crime_description,
                v.descent,
                TO_CHAR(c.date_committed, 'YYYY-MM')
            `;
            finalSelect = `
                vc.crime_description,
                vc.crime_month,
                vc.descent,
                vc.victim_count
            `
            break;
        default:
            // Default case if the type provided doesn't match any known category
            throw new Error('Invalid type specified. Valid options are "age", "sex", or "descent".');
    }
    // Trim the last comma off the selectClause to avoid SQL syntax errors
    selectClause = selectClause.trim().replace(/,\s*$/, '');

    return `
        WITH VictimCounts AS (
            SELECT
                ${selectClause},
                COUNT(*) AS victim_count
            FROM
                Victim v
            INNER JOIN
                Crime c ON v.crimeID = c.crimeID
            INNER JOIN
                CrimeType ct ON c.crime_code = ct.crime_code
            WHERE
                c.date_committed BETWEEN TO_DATE('${startDate}', 'YYYY-MM-DD') AND TO_DATE('${endDate}', 'YYYY-MM-DD')
                ${crimeDescriptions.length > 0 ? `AND ct.crime_description IN (${crimeDescriptions.map(crime => `'${crime}'`).join(", ")})` : ''}
            GROUP BY
                ${groupByClause}
        )
        SELECT 
            ${finalSelect}
        FROM
            VictimCounts vc
        ORDER BY
            vc.crime_month
    `;
};

const query3Daily = (startDate, endDate, crimeDescriptions, type='descent') => {
    let groupByClause = '';
    let selectClause = '';
    let finalSelect = '';
    switch (type) {
        case 'age':
            selectClause = `
                ct.crime_description,
                TO_CHAR(c.date_committed, 'YYYY-MM-DD') AS crime_month,
                TRUNC((EXTRACT(YEAR FROM SYSDATE) - v.age) / 10) * 10 AS age_group,
            `;
            groupByClause = `
                ct.crime_description,
                TO_CHAR(c.date_committed, 'YYYY-MM-DD'),
                TRUNC((EXTRACT(YEAR FROM SYSDATE) - v.age) / 10) * 10
            `;
            finalSelect = `
                vc.crime_description,
                vc.crime_month,
                vc.age_group,
                vc.victim_count
            `
            break;
        case 'sex':
            selectClause = `
                ct.crime_description,
                v.sex,
                TO_CHAR(c.date_committed, 'YYYY-MM-DD') AS crime_month,
            `;
            groupByClause = `
                ct.crime_description,
                v.sex,
                TO_CHAR(c.date_committed, 'YYYY-MM-DD')
            `;
            finalSelect = `
                vc.crime_description,
                vc.crime_month,
                vc.sex,
                vc.victim_count
            `
            break;
        case 'descent':
            selectClause = `
                ct.crime_description,
                v.descent,
                TO_CHAR(c.date_committed, 'YYYY-MM-DD') AS crime_month,
            `;
            groupByClause = `
                ct.crime_description,
                v.descent,
                TO_CHAR(c.date_committed, 'YYYY-MM-DD')
            `;
            finalSelect = `
                vc.crime_description,
                vc.crime_month,
                vc.descent,
                vc.victim_count
            `
            break;
        default:
            // Default case if the type provided doesn't match any known category
            throw new Error('Invalid type specified. Valid options are "age", "sex", or "descent".');
    }

    // Trim the last comma off the selectClause to avoid SQL syntax errors
    selectClause = selectClause.trim().replace(/,\s*$/, '');

    return `
        WITH VictimCounts AS (
            SELECT
                ${selectClause},
                COUNT(*) AS victim_count
            FROM
                Victim v
            INNER JOIN
                Crime c ON v.crimeID = c.crimeID
            INNER JOIN
                CrimeType ct ON c.crime_code = ct.crime_code
            WHERE
                c.date_committed BETWEEN TO_DATE('${startDate}', 'YYYY-MM-DD') AND TO_DATE('${endDate}', 'YYYY-MM-DD')
                ${crimeDescriptions.length > 0 ? `AND ct.crime_description IN (${crimeDescriptions.map(crime => `'${crime}'`).join(", ")})` : ''}
            GROUP BY
                ${groupByClause}
        )
        SELECT 
            ${finalSelect}
        FROM
            VictimCounts vc
        ORDER BY
            vc.crime_month
    `;
};

const query4Monthly = (startDate,endDate,areas,crimeDescriptions) => `
WITH TimeDifference AS (
    SELECT 
        c.area_code,
        c.crimeID,
        ct.crime_description,
        (CAST(c.date_reported AS DATE) - CAST(c.date_committed AS DATE)) AS time_difference
    FROM 
        Crime c
    INNER JOIN CrimeType ct ON c.crime_code = ct.crime_code
),
MonthlyTimeDifferences AS (
    SELECT 
        a.area_name,
        ct.crime_description,
        TO_CHAR(c.date_committed, 'YYYY-MM') AS crime_month,
        ROUND(AVG(time_difference),3) AS average_time_difference,
        PERCENTILE_CONT(0) WITHIN GROUP (ORDER BY time_difference) AS minimum,
        PERCENTILE_CONT(0.25) WITHIN GROUP (ORDER BY time_difference) AS first_quartile,
        PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY time_difference) AS median,
        PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY time_difference) AS third_quartile,
        PERCENTILE_CONT(1) WITHIN GROUP (ORDER BY time_difference) AS maximum
    FROM 
        Crime c
        JOIN CrimeType ct ON c.crime_code = ct.crime_code
        JOIN Area a ON c.area_code = a.area_code
        JOIN TimeDifference td on c.crimeID = td.crimeID
    WHERE 
        c.date_committed BETWEEN TO_DATE('${startDate}', 'YYYY-MM-DD') AND TO_DATE('${endDate}', 'YYYY-MM-DD')
        ${crimeDescriptions.length > 0 ? `AND ct.crime_description IN (${crimeDescriptions.map(crime => `'${crime}'`).join(", ")})` : ''}
        ${areas.length > 0 ? `AND a.area_name IN (${areas.map((area, index) => `'${area}'`).join(", ")})` : ''}
    GROUP BY 
        a.area_name,
        ct.crime_description,
        TO_CHAR(c.date_committed, 'YYYY-MM')
)
SELECT
    area_name,
    crime_description,
    crime_month,
    average_time_difference,
    minimum,
    first_quartile,
    median,
    third_quartile,
    maximum,
    third_quartile - first_quartile AS interQuantileRange
FROM 
    MonthlyTimeDifferences mtd
ORDER BY
    mtd.area_name,
    mtd.crime_description,
    mtd.crime_month DESC
`;
const query4Daily = (startDate,endDate,areas,crimeDescriptions) => `
WITH TimeDifference AS (
    SELECT 
        c.area_code,
        c.crimeID,
        ct.crime_description,
        (CAST(c.date_reported AS DATE) - CAST(c.date_committed AS DATE)) AS time_difference
    FROM 
        Crime c
    INNER JOIN CrimeType ct ON c.crime_code = ct.crime_code
),
DailyTimeDifferences AS (
    SELECT 
        a.area_name,
        ct.crime_description,
        TO_CHAR(c.date_committed, 'YYYY-MM-DD') AS crime_day,
        ROUND(AVG(time_difference),3) AS average_time_difference,
        PERCENTILE_CONT(0) WITHIN GROUP (ORDER BY time_difference) AS minimum,
        PERCENTILE_CONT(0.25) WITHIN GROUP (ORDER BY time_difference) AS first_quartile,
        PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY time_difference) AS median,
        PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY time_difference) AS third_quartile,
        PERCENTILE_CONT(1) WITHIN GROUP (ORDER BY time_difference) AS maximum
    FROM 
        Crime c
        JOIN CrimeType ct ON c.crime_code = ct.crime_code
        JOIN Area a ON c.area_code = a.area_code
        JOIN TimeDifference td on c.crimeID = td.crimeID
    WHERE 
        c.date_committed BETWEEN TO_DATE('${startDate}', 'YYYY-MM-DD') AND TO_DATE('${endDate}', 'YYYY-MM-DD')
        ${crimeDescriptions.length > 0 ? `AND ct.crime_description IN (${crimeDescriptions.map(crime => `'${crime}'`).join(", ")})` : ''}
        ${areas.length > 0 ? `AND a.area_name IN (${areas.map((area, index) => `'${area}'`).join(", ")})` : ''}
    GROUP BY 
        a.area_name,
        ct.crime_description,
        TO_CHAR(c.date_committed, 'YYYY-MM-DD')
)
SELECT
    *
FROM 
    DailyTimeDifferences dtd
ORDER BY
    dtd.area_name,
    dtd.crime_description,
    dtd.crime_day DESC
`;

const query5Monthly = (startDate, endDate, premise, crimeDescriptions) => {
    let crimeDescriptionCondition = '';
    if (crimeDescriptions.length > 0) {
        if (!Array.isArray(crimeDescriptions)) {
            crimeDescriptionCondition = `AND CrimeType.crime_description = '${crimeDescriptions}'`;
        } else {
            crimeDescriptionCondition = `AND CrimeType.crime_description IN (${crimeDescriptions.map(crime => `'${crime}'`).join(", ")})`;
        }
    }

    return `
        SELECT 
            CrimeType.crime_description,
            COUNT(*) AS num_crimes,
            TO_CHAR(date_committed, 'YYYY-MM') AS month
        FROM 
            Crime
        JOIN 
            Premise ON Crime.premise_code = Premise.premise_code
        JOIN
            CrimeType ON Crime.crime_code = CrimeType.crime_code
        WHERE 
            Premise.premise_description = '${premise}' 
            ${crimeDescriptionCondition}
            AND date_committed BETWEEN TO_DATE('${startDate}', 'YYYY-MM-DD') AND TO_DATE('${endDate}', 'YYYY-MM-DD') 
        GROUP BY 
            TO_CHAR(date_committed, 'YYYY-MM'),
            CrimeType.crime_description
        ORDER BY 
            TO_CHAR(date_committed, 'YYYY-MM'),
            CrimeType.crime_description`;
};

const query5Daily = (startDate, endDate, premise, crimeDescriptions) => {
    let crimeDescriptionCondition = '';
    if (crimeDescriptions.length > 0) {
        if (!Array.isArray(crimeDescriptions)) {
            crimeDescriptionCondition = `AND CrimeType.crime_description = '${crimeDescriptions}'`;
        } else {
            crimeDescriptionCondition = `AND CrimeType.crime_description IN (${crimeDescriptions.map(crime => `'${crime}'`).join(", ")})`;
        }
    }

    return `
        SELECT 
            CrimeType.crime_description,
            COUNT(*) AS num_crimes,
            TO_CHAR(date_committed, 'YYYY-MM-DD') AS day
        FROM 
            Crime
        JOIN 
            Premise ON Crime.premise_code = Premise.premise_code
        JOIN
            CrimeType ON Crime.crime_code = CrimeType.crime_code
        WHERE 
            Premise.premise_description = '${premise}' 
            ${crimeDescriptionCondition}
            AND date_committed BETWEEN TO_DATE('${startDate}', 'YYYY-MM-DD') AND TO_DATE('${endDate}', 'YYYY-MM-DD') 
        GROUP BY 
            TO_CHAR(date_committed, 'YYYY-MM-DD'),
            CrimeType.crime_description
        ORDER BY 
            TO_CHAR(date_committed, 'YYYY-MM-DD'),
            CrimeType.crime_description`;
};


module.exports = { getVictimInfoString, query1Daily, query1Monthly, getAreasQuery, getCrimeTypesQuery, query2Daily, query2Monthly, query3Daily, query3Monthly, getWeaponDescriptionsQuery, query4Monthly, query4Daily, query5Daily, query5Monthly, getPremisesQuery};


