require('dotenv').config();
const express = require('express');
const cors = require('cors');
const queryRoutes = require('./query.js')
const { initialize } = require('./db'); // Adjust the path as necessary

const app = express();
app.use(cors());
app.use(express.json());

app.use((req, res, next) => {
    console.log(req.path, req.method);
    next();
});
app.use('/api', queryRoutes)
// Initialize database connection and start server
initialize().then(() => {
    app.listen(process.env.PORT, () => {
        console.log('Server is listening on port', process.env.PORT);
    });
}).catch(err => {
    console.error('Failed to make database connection!', err);
}); 
