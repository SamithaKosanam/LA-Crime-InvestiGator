
const express = require('express')
const router = express.Router();

const { getVictimInfo, getCrimeTypes, queryDatabase, query1CrimeTypes, getAreas, query2WeaponTypes, query3VictimDemographics, query3VictimSex, getWeaponDescriptions, query4TimeDifferences, query5Premise, getPremises} = require('./queryController.js')


router.get('/test', queryDatabase)
router.get('/query1', query1CrimeTypes)
router.get('/query2', query2WeaponTypes)
router.get('/query3', query3VictimSex)
router.get('/query4', query4TimeDifferences)
router.get('/query5', query5Premise)
router.get('/areas', getAreas)
router.get('/premises', getPremises)
router.get('/crimeTypes', getCrimeTypes)
router.get('/weaponTypes', getWeaponDescriptions)
router.get('/victimInfo', getVictimInfo)

module.exports = router