// db.js
require('dotenv').config();
const oracledb = require('oracledb');

let connection;

async function initialize() {
  try {
    connection = await oracledb.getConnection({
      user: process.env.ORACLE_USERNAME,
      password: process.env.ORACLE_PASSWORD,
      connectString: process.env.ORACLE_CONNECT_STRING
    });
    console.log('Successfully connected to Oracle Database');
    
    // Execute ALTER SESSION statement
    await connection.execute('alter session set current_schema = "NISHANT.NAGURURU"');
    console.log('Successfully set current schema');

  } catch (err) {
    console.error('Error connecting to the database or setting current schema:', err);
    process.exit(1);
  }
}

function getConnection() {
  if (!connection) {
    throw new Error('Connection has not been established. Please call initialize first.');
  }
  return connection;
}

module.exports = { initialize, getConnection };
